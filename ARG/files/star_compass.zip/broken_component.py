def getAngle():
    
    # Three coins lie before you bright —
    # Silver, bronze, and gold in sight.
    # A scale you hold to weigh their worth,
    # To find how many silvers match their girth.

    # First you place one gold on one side,
    # Against three bronze coins piled with pride.
    # The scale is balanced — a perfect match,
    # One gold equals three bronze — a simple catch.

    # Next you weigh two golds with care,
    # Against five silvers light as air.
    # The scale tips even, side by side,
    # Five silvers equal two golds, implied.

    # Now the question: with this known,
    # How many silvers weigh as much as bronze alone—
    # Eighteen bronze coins, stacked in a line?

    # Speak the answer, clear and fine.
    
    silver_coins = 15
    
    return silver_coins