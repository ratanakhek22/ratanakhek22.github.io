import tkinter as tk
from PIL import Image, ImageTk
import os
import broken_component

# Hidden URL Combination: 111001001

# Load image from same directory
script_dir = os.path.dirname(os.path.abspath(__file__))
constellation_path = os.path.join(script_dir, "constellations.jpg")
constellation_image = Image.open(constellation_path).resize((750, 750))
compass_head_path = os.path.join(script_dir, "compass_head.png")
compass_head_image = Image.open(compass_head_path).resize((30, 30))

root = tk.Tk()
root.title("Star Compass")
root.geometry("750x800")  # 750 for image + 50 for buttons
root.resizable(False, False)

# Top frame for image
image_frame = tk.Frame(root, width=750, height=750, highlightbackground="black", highlightthickness=2)
image_frame.place(x=0, y=0)

# Bottom frame for buttons (placed just below the image frame)
button_frame = tk.Frame(root, width=750, height=50, highlightbackground="black", highlightthickness=2)
button_frame.place(x=0, y=750)

# Image label inside image_frame
constellation = ImageTk.PhotoImage(constellation_image)
image_label = tk.Label(image_frame, image=constellation, borderwidth=0, relief="flat")
image_label.pack(expand=True)

# Compass head
head = ImageTk.PhotoImage(compass_head_image)
head_label = tk.Label(image_frame, image=head, borderwidth=0, relief="flat")
head_label.place(x=360, y=725)

# Track rotation angle
current_angle = 0
angle_display = tk.StringVar()
angle_display.set("Angle: 0")

stack = [-1, -1, -1, -1, -1, -1, -1, -1, -1]
def combo_check(new_elem):
    stack.pop(0)
    stack.append(new_elem)
    if stack == [1, 1, 1, 0, 0, 1, 0, 0, 1]:
        angle_display.set("ratanakhek22.github.io/ARG/9807254363.html")

def update_image(angle):
    # Rotate the original resized image every time, not the rotated one
    rotated = constellation_image.rotate(angle, expand=False, fillcolor="#0B182b")

    tk_image = ImageTk.PhotoImage(rotated)
    image_label.config(image=tk_image)
    image_label.image = tk_image

def rotate_left():
    global current_angle
    current_angle = (current_angle - broken_component.getAngle()) % 360
    update_image(current_angle)
    angle_display.set("Angle: " + str(current_angle))
    combo_check(0)

def rotate_right():
    global current_angle
    current_angle = (current_angle + broken_component.getAngle()) % 360
    update_image(current_angle)
    angle_display.set("Angle: " + str(current_angle))
    combo_check(1)

# Create buttons inside button_frame
tk.Button(button_frame, text="⟲ Rotate Left", command=rotate_left).place(x=120, y=10)
tk.Button(button_frame, text="Rotate Right ⟳", command=rotate_right).place(x=220, y=10)
tk.Label(button_frame, textvariable=angle_display).place(x=350, y=15)

root.mainloop()