The important files are compass.py and broken_component.py

compass.py does not work properly because the component is not fixed yet.

Run compass.py when you are ready to use the tool.

I recommend looking at both even though you only need to edit the broken one.