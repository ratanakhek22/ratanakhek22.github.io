Instructions on how to use python vai this directory.

- How to run a script
    - Run the startup.bat
    - Use the console/terminal that pops up
    - Run your script like normal ("python myScript.py")

- Creating new python files
    - Create the file under the root directory ("Python_Setup")

- Ask a TA for help if not working