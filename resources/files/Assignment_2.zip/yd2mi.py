yard = 10
mile = yard / 1760

print(mile)