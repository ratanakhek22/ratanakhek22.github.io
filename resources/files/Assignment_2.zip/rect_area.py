base = 10
height = 20

area = base * height
print(area)