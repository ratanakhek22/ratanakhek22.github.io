feet = 10
yard = feet / 3

print(yard)