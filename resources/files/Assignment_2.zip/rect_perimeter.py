base = 10
height = 20

perimeter = base + base + height + height
print(perimeter)