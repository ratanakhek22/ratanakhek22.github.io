inches = 10
feet = inches / 12

print(feet)