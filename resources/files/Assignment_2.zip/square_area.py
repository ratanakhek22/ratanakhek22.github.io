side = 10

area = side * side
print(area)