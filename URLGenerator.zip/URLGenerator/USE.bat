@echo off 
python code.py number.txt -r