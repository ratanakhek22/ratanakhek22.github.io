import sys
import time
import random

with open(sys.argv[1], 'r') as my_file:
    num = float(my_file.read())
    if int(num) != num:
        num = round(num, 6)
    random.seed(num)
    print("https://ratanakhek22.github.io/" + str(abs(random.randint(10000000, 99999999))))
    time.sleep(5)
